import {Component } from '@angular/core'
import {AuthenticationService, UserDetails} from '../authentication.service'
import { Router } from '@angular/router'

@Component({
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.css']

})

export class ProfileComponent {
  
        details:UserDetails

   
    constructor(public auth: AuthenticationService,private router : Router){}

    ngOnInit() {

        //is localstorage is empty -> redirect to login

        if(localStorage.getItem("usertoken") == null){
            alert('Please login First')
            this.router.navigateByUrl('/profile')
        }
        this.auth.profile().subscribe(
            user => {
                this.details =user
            },
            err => {
                console.error(err)
            }
        )
    }

}